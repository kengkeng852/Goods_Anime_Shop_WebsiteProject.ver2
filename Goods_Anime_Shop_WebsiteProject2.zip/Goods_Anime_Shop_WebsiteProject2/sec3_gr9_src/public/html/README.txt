Y2T2 Project: Goods Days

This project is written by:
1. Kongphob Wutthiumphol
2. Chommakorn Sontesadisai
3. Nattanicha Sinsawet
4. Poohtanmai Siriwachirapap

Project Description:
 Our website is marketplace that show all the source of anime goods, and then link to website that sell on each product  
 It has anime goods from Onepiece, Gundam, and Attack On Titan.

Step For Running Project:
Installation
1. Install VSCode via this link:
    https://code.visualstudio.com/
2. Install HTML
    Name: HTML CSS Support
    Id: ecmel.vscode-html-css
    Description: CSS Intellisense for HTML
    Version: 1.13.1
    Publisher: ecmel
    VS Marketplace Link: https://marketplace.visualstudio.com/items?itemName=ecmel.vscode-html-css
3. Install LiveServer
    Name: Live Server
    Id: ritwickdey.LiveServer
    Description: Launch a development local Server with live reload feature for static & dynamic pages
    Version: 5.7.9
    Publisher: Ritwick Dey
    VS Marketplace Link: https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer

Running
1. Click right at the index.html file 
2. Click open with live server
3. Then you can click any button on our project

Font Family
https://fonts.googleapis.com/css?family=Poppins
http://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swa

Font Awesome (icon)
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css
https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css
https://unpkg.com/boxicons@latest/css/boxicons.min.css

Theme
https://cdn.discordapp.com/attachments/1074658173765550151/1077974289493544970/IMG_1732.png

References
Search Bar: https://www.youtube.com/watch?v=9hnJsNIBq1g&feature=youtu.be
User Management: https://www.youtube.com/watch?v=IqAPhLLd_bM&t=1s
Product Result and Product Admin /Header/Footer: https://www.youtube.com/watch?v=cLOT0APQzDs
About us: https://www.youtube.com/watch?v=s3NDJ4twCDg&list=PLeZhXsDkBWaXDFSC0P9CpF_q9gocJ8KRy&index=6
Contact us: https://www.youtube.com/watch?v=f0DcnrpeBv8 

individually work:
First Phase:
Work together: Readme.txt and Navigation Dream
- Kongphob Wutthiumphol: Search page/ detail page
- Chommakorn Sontesadisai: Admin page / User management page / Product management page
- Nattanicha Sinsawet: About us page / Contact us page
- Poohtanmai Siriwachirapap: Homepage + Log-in + sign-up